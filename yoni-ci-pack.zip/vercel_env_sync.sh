#!/usr/bin/env bash
set -euo pipefail
VARS=(OPENAI_API_KEY STRIPE_WEBHOOK_SECRET GITHUB_WEBHOOK_SECRET GITHUB_APP_INSTALLATION_TOKEN X148_ALIAS)
for VAR in "${VARS[@]}"; do
  VAL="${!VAR:-}"
  if [ -n "${VAL}" ]; then
    printf "%s" "$VAL" | vercel env add "$VAR" production || true
    printf "%s" "$VAL" | vercel env add "$VAR" preview || true
  else
    echo "⚠️  $VAR is empty; skipped"
  fi
done
vercel env ls || true
