# CI: Duplicate Route Guard + Vercel ENV Sync

Adds:
- `.github/workflows/route-duplicates.yml`
- `vercel_env_sync.sh`

## Use
```bash
vercel link  # first time
export OPENAI_API_KEY=...
export STRIPE_WEBHOOK_SECRET=...
export GITHUB_WEBHOOK_SECRET=...
export GITHUB_APP_INSTALLATION_TOKEN=...
export X148_ALIAS=148-Amon
bash vercel_env_sync.sh
```
