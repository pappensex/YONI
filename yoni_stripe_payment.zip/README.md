# YONI APP – Stripe Payment Flow (EARTH ROOT / LIONHEART / FIRE ASCENT)

Dieses Paket enthält einen kompletten, lauffähigen Zahlungsflow für eine Next.js-App
mit App Router (z. B. `app/` Ordner). Es ist dafür gedacht, in dein bestehendes
YONI-App-Projekt integriert zu werden.

## Dateien in diesem Paket

- `lib/stripe.ts` – zentrale Stripe-Initialisierung
- `app/api/checkout/route.ts` – erstellt Stripe Checkout Sessions
- `app/api/portal/route.ts` – öffnet das Customer Billing Portal
- `app/pricing/page.tsx` – Pricing-Seite mit deinen drei Plänen
- `components/PricingTable.tsx` – separates Pricing-UI

## ENV Variablen

Lege in deinem Projekt (z. B. `.env.local`) folgende Variablen an:

```env
STRIPE_SECRET_KEY=sk_live_...          # dein Stripe Secret Key
STRIPE_PRICE_EARTH_ROOT=price_...      # Preis-ID für EARTH ROOT (11 € / Monat)
STRIPE_PRICE_LIONHEART=price_...       # Preis-ID für LIONHEART (44 € / Monat)
STRIPE_PRICE_FIRE_ASCENT=price_...     # Preis-ID für FIRE ASCENT (111 € / Monat)
STRIPE_CUSTOMER_PORTAL_RETURN_URL=https://deine-domain.tld/pricing
NEXT_PUBLIC_APP_URL=https://deine-domain.tld
```

Die `price_...` IDs erhältst du aus dem Stripe Dashboard beim jeweiligen Produkt.

## Integration in dein Projekt

1. Kopiere die Inhalte dieses ZIPs in dein bestehendes Next.js Projekt (z. B. YONI-app).
   - `lib/stripe.ts` nach `lib/stripe.ts`
   - `app/api/checkout/route.ts` nach `app/api/checkout/route.ts`
   - `app/api/portal/route.ts` nach `app/api/portal/route.ts`
   - `app/pricing/page.tsx` nach `app/pricing/page.tsx`
   - `components/PricingTable.tsx` nach `components/PricingTable.tsx`
2. Stelle sicher, dass `typescript` und `stripe` installiert sind:
   ```bash
   npm install stripe
   ```
3. Next.js Dev-Server starten:
   ```bash
   npm run dev
   ```
4. Öffne im Browser `/pricing` und teste die drei Buttons.
5. Teste die Webhooks später separat, wenn du Abostatus synchron halten möchtest.

Dieses Paket kümmert sich um:
- Erstellung einer Stripe Checkout Session
- Redirect zum Stripe Checkout
- Öffnen des Customer Billing Portals
- UI für EARTH ROOT / LIONHEART / FIRE ASCENT in Gold/Violett Branding
