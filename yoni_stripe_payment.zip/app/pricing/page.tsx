import { PricingTable } from "@/components/PricingTable";

export default function PricingPage() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-black via-violet-950 to-black text-white">
      <div className="pt-16 pb-24">
        <PricingTable />
      </div>
    </main>
  );
}
