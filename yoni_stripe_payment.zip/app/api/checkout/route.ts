import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";

const priceMap: Record<string, string | undefined> = {
  earth_root: process.env.STRIPE_PRICE_EARTH_ROOT,
  lionheart: process.env.STRIPE_PRICE_LIONHEART,
  fire_ascent: process.env.STRIPE_PRICE_FIRE_ASCENT,
};

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { plan } = body as { plan?: string };

    if (!plan || !priceMap[plan]) {
      return NextResponse.json(
        { error: "Invalid or missing plan" },
        { status: 400 }
      );
    }

    const priceId = priceMap[plan];
    const baseUrl =
      process.env.NEXT_PUBLIC_APP_URL || req.nextUrl.origin;

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      payment_method_types: ["card"],
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      success_url: `${baseUrl}/pricing?status=success&plan=${plan}`,
      cancel_url: `${baseUrl}/pricing?status=cancel`,
    });

    return NextResponse.json({ url: session.url });
  } catch (error) {
    console.error("Error creating checkout session", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
