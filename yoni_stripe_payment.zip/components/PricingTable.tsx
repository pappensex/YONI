"use client";

import { useState } from "react";

type PlanKey = "earth_root" | "lionheart" | "fire_ascent";

interface Plan {
  key: PlanKey;
  title: string;
  price: string;
  description: string;
  features: string[];
  highlight?: boolean;
}

const plans: Plan[] = [
  {
    key: "earth_root",
    title: "EARTH ROOT",
    price: "11 € / Monat",
    description: "Basis-Stabilität. Energetische Erdung und YONI-Impulse.",
    features: [
      "Tägliche YONI-Impulse",
      "Manifestations-Notizen",
      "Monatliches Alignment-PDF",
      "Zugang zum Basisraum",
    ],
  },
  {
    key: "lionheart",
    title: "LIONHEART",
    price: "44 € / Monat",
    description: "Kreative Selbstführung, Identität und Ausdruck.",
    features: [
      "Alles aus EARTH ROOT",
      "Audio-Drops & Deep Dives",
      "Identity-Workflows",
      "Creative-Leadership-Tools",
      "Monatliche Q&A-Energie-Session",
    ],
    highlight: true,
  },
  {
    key: "fire_ascent",
    title: "FIRE ASCENT",
    price: "111 € / Monat",
    description: "High-Impact Feuer für echte Durchbrüche.",
    features: [
      "Alles aus LIONHEART",
      "High-Impact Sessions",
      "Feuer-Rituale & Commands",
      "Monatliches Fire-Alignment",
      "Priority Access & exklusive Codes",
    ],
  },
];

export function PricingTable() {
  const [loadingPlan, setLoadingPlan] = useState<PlanKey | null>(null);

  const handleSubscribe = async (planKey: PlanKey) => {
    try {
      setLoadingPlan(planKey);
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ plan: planKey }),
      });

      if (!res.ok) {
        console.error("Checkout error", await res.text());
        setLoadingPlan(null);
        return;
      }

      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        setLoadingPlan(null);
      }
    } catch (error) {
      console.error(error);
      setLoadingPlan(null);
    }
  };

  return (
    <div className="mx-auto max-w-5xl px-4 py-12">
      <div className="text-center mb-10">
        <h1 className="text-3xl md:text-4xl font-bold text-yellow-300 drop-shadow">
          YONI ASCENSION
        </h1>
        <p className="mt-3 text-sm md:text-base text-violet-100">
          Drei Wege. Eine Energie. Gold + Violett. Deine Signatur.
        </p>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        {plans.map((plan) => (
          <div
            key={plan.key}
            className={`flex flex-col rounded-2xl border bg-gradient-to-b from-violet-900/80 to-black/80 p-6 shadow-xl ${
              plan.highlight
                ? "border-yellow-300 shadow-yellow-500/30 scale-[1.02]"
                : "border-violet-700"
            }`}
          >
            <div className="mb-4">
              <h2 className="text-xl font-semibold text-yellow-200">
                {plan.title}
              </h2>
              <p className="mt-1 text-sm text-violet-100">
                {plan.description}
              </p>
            </div>
            <div className="mb-4">
              <span className="text-2xl font-bold text-yellow-300">
                {plan.price}
              </span>
            </div>
            <ul className="mb-6 space-y-2 text-sm text-violet-100">
              {plan.features.map((feature) => (
                <li key={feature} className="flex gap-2">
                  <span className="mt-1 h-1.5 w-1.5 rounded-full bg-yellow-300" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            <button
              onClick={() => handleSubscribe(plan.key)}
              disabled={loadingPlan === plan.key}
              className="mt-auto rounded-full bg-yellow-300 px-4 py-2 text-sm font-semibold text-black shadow hover:bg-yellow-200 disabled:opacity-60"
            >
              {loadingPlan === plan.key
                ? "Weiterleitung …"
                : "Jetzt Zugang aktivieren"}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
